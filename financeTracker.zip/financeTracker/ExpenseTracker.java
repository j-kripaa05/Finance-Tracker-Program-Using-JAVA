import java.util.*;

class ExpenseTracker {
    private ArrayList<Expense> expenses;

    public ExpenseTracker() {
        expenses = new ArrayList<>();
    }

    public void addExpense(String description, double amount) {
        Expense expense = new Expense(description, amount);
        expenses.add(expense);
    }

    public void removeExpense(String description, double amount) {
        expenses.removeIf(expense -> expense.description.equals(description) && expense.amount == amount); 
    }

    public void dailyReport() {
        System.out.println("Daily Expense Report:");
        double total = 0;
        for (Expense expense : expenses) {
            System.out.println(expense);
            total += expense.amount;
        }
        System.out.println("Total Expenses: $" + total);
        double limit=0;
        System.out.println("Enter your expense limit : ");
        Scanner obj= new Scanner(System.in);
        limit = obj.nextDouble();
        
        if (total>limit) {
            System.out.println("You have exceed your Daily Limit");            
        }else if (total ==limit ) {
            System.out.println("You have reached your daily limit");
        } else {
            System.out.println("You haven't reached your limit");
        }
    }

    public void clearExpenses() {
        expenses.clear();
    }
}
