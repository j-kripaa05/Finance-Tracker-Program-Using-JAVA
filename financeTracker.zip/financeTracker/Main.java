import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        ExpenseTracker eTracker = new ExpenseTracker();
        boolean start = true;

        while (start) {
            
            System.out.println("Choose an option:");
            System.out.println("1. Add Expense");
            System.out.println("2. Remove Expense");
            System.out.println("3. Show Daily Report");
            System.out.println("4. Exit");

            int i = obj.nextInt();
            obj.nextLine();

            switch (i) {
                case 1:
                    System.out.print("Enter expense description: ");
                    String description = obj.nextLine();
                    System.out.print("Enter expense amount: ");
                    double amount = obj.nextDouble();
                    eTracker.addExpense(description, amount);
                    break;
                case 2:
                    System.out.print("Enter expense description: ");
                    description = obj.nextLine();
                    System.out.print("Enter expense amount: ");
                    amount = obj.nextDouble();
                    eTracker.removeExpense(description, amount);
                    break;
                case 3:
                    eTracker.dailyReport();
                    break;
                case 4:
                    start = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

    }
}
